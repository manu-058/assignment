import React from "react";
import ReactDOM from "react-dom";
import AppShell from "./appShell";

ReactDOM.render(
  <React.StrictMode>
    <AppShell />
  </React.StrictMode>,
  document.getElementById("root")
);
