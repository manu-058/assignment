import React from "react";
import { Button, Grid2, ToggleButton, ToggleButtonGroup } from "@mui/material";
import SettingsIcon from "@mui/icons-material/Settings";
import BarChartIcon from "@mui/icons-material/BarChart";
import SummarizeIcon from "@mui/icons-material/Summarize";
import SaveIcon from "@mui/icons-material/Save";
import DetailsTable from "./detailsTable";

function Details() {
  return (
    <Grid2 container rowSpacing={2}>
      <Grid2 size="grow">
        <ToggleButtonGroup exclusive color="primary" size="small">
          <ToggleButton value="web" selected>
            <SettingsIcon />
            Data
          </ToggleButton>
          <ToggleButton value="android">
            <BarChartIcon />
            Summary
          </ToggleButton>
          <ToggleButton value="ios">
            <SummarizeIcon />
            Logs
          </ToggleButton>
        </ToggleButtonGroup>
      </Grid2>
      <Grid2>
        <Button
          disabled
          size="small"
          startIcon={<SaveIcon />}
          variant="contained"
          disableElevation
        >
          Download
        </Button>
      </Grid2>
      <Grid2 size={12}>
        <DetailsTable />
      </Grid2>
    </Grid2>
  );
}

export default Details;
