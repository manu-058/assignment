// theme.js
import { createTheme } from "@mui/material/styles";

const theme = createTheme({
  palette: {
    primary: {
      main: "#2c0060",
      light: "#f4f6fc",
      dark: "#2d0362",
      contrastText: "#ffffff",
    },
    secondary: {
      main: "#f1229e",
      light: "#fbc5e5",
      dark: "#f1229e",
      contrastText: "#ffffff",
    },
    background: {
      default: "#f4f6fc", // Background color
      paper: "#f4f6fc", // Card/Container color
    },
    text: {
      primary: "#000000",
      secondary: "#555555",
    },
  },
  typography: {
    fontFamily: "'Roboto', 'Arial', sans-serif",
    h1: {
      fontSize: "2rem",
      fontWeight: 500,
    },
    h2: {
      fontSize: "1.75rem",
      fontWeight: 500,
    },
    body1: {
      fontSize: "1rem",
      color: "#333333",
    },
    button: {
      textTransform: "none", // Disable uppercase text in buttons
    },
  },
  spacing: 8, // Default spacing multiplier (8px)
  components: {
    MuiButton: {
      styleOverrides: {
        root: {
          padding: "8px 16px",
        },
      },
    },
  },
});

export default theme;
