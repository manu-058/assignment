import { configureStore } from "@reduxjs/toolkit";
import loadDetailsReducer from "./slice/appSlice";

export const store = configureStore({
  reducer: {
    projectData: loadDetailsReducer,
  },
});
