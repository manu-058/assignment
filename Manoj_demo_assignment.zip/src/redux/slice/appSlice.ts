import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  data: null,
};

export const loadDetailsSlice = createSlice({
  name: "projectData",
  initialState,
  reducers: {
    updatedData: (state, action) => {
      state.data = action.payload;
    },
  },
});

export const { updatedData } = loadDetailsSlice.actions;

export default loadDetailsSlice.reducer;
