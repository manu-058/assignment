import React, { useEffect } from "react";
import { Grid2, styled } from "@mui/material";
import { useDispatch } from "react-redux";
import { updatedData } from "./redux/slice/appSlice";
import Header from "./headerCmp";
import Details from "./details";
import Actions from "./action";
import data from "./data/sample.json";

const Container = styled(Grid2)`
  padding: 16px;
`;

interface ITableHeader {
  name: string;
  type: string;
}

const App = () => {
  const dispatch = useDispatch();

  useEffect(() => {
    const _formatedData: any = data;
    _formatedData.table_headers = (
      data.table_headers as Array<ITableHeader>
    ).map((item) => ({
      id: item.name,
      field: item.name,
      headerName: item.name,
    }));

    _formatedData.table_data = (data?.table_data).map((row) => {
      const obj: any = {};
      _formatedData.table_headers.forEach((col: any, index: number) => {
        obj[col?.field] = row[index];
      });
      return obj;
    });

    dispatch(updatedData(_formatedData));
  }, []);

  return (
    <>
      <header>
        <Header />
      </header>
      <Container container columnSpacing={2}>
        <Grid2 size={9}>
          <Details />
        </Grid2>
        <Grid2 size={3}>
          <Actions />
        </Grid2>
      </Container>
    </>
  );
};

export default App;
