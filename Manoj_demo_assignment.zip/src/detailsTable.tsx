import React from "react";
import { DataGrid } from "@mui/x-data-grid";
import { Chip, styled, Typography } from "@mui/material";
import AcUnitIcon from "@mui/icons-material/AcUnit";
import StorageIcon from "@mui/icons-material/Storage";
import { useSelector } from "react-redux";

const Container = styled("div")`
  display: flex;
  flex-direction: column;
  border: solid 2px lightgray;
  border-radius: 6px 6px 0px 0px;
`;

const ContainerHeader = styled("div")`
  display: flex;
  flex-direction: row;
  border-bottom: solid 2px lightgray;
  padding: 16px 24px;
  flex-wrap: wrap;
`;

const ChipsContainer = styled("div")`
  flex-grow: 1;
  display: flex;
  column-gap: 4px;
  flex-wrap: wrap;
`;
const ChipText = styled(Typography)`
  margin: 0px 4px;
`;
function DetailsTable() {
  const details = useSelector((state: any) => state.projectData);
  return (
    <Container>
      <ContainerHeader>
        <ChipsContainer>
          <Chip
            size="small"
            color="primary"
            icon={<AcUnitIcon />}
            label="PROJECT NAME"
          />
          <ChipText>ETL New Demo 2</ChipText>
          <Chip
            size="small"
            color="primary"
            icon={<StorageIcon />}
            label="OUTPUT DATASET NAME"
          />
          <ChipText>ETL New Demo 2</ChipText>

          <Chip size="small" color="primary" label="LAST RUN" />
          <ChipText>Not available</ChipText>
        </ChipsContainer>
        <Typography color="#626c8a">{`Rows: ${details?.data?.row_count}`}</Typography>
      </ContainerHeader>
      <DataGrid
        getRowId={(row) => row?.Row}
        rows={details?.data?.table_data || []}
        columns={details?.data?.table_headers || []}
        hideFooterPagination
      />
    </Container>
  );
}

export default DetailsTable;
