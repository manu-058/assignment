import React from "react";
import { useSelector } from "react-redux";
import { styled, alpha } from "@mui/material/styles";
import { SimpleTreeView } from "@mui/x-tree-view/SimpleTreeView";
import { TreeItem, treeItemClasses } from "@mui/x-tree-view/TreeItem";
import { IconButton, Typography } from "@mui/material";
import CloseIcon from "@mui/icons-material/Close";
import DownloadIcon from "@mui/icons-material/Download";
import SystemUpdateAltIcon from "@mui/icons-material/SystemUpdateAlt";
import SaveIcon from "@mui/icons-material/Save";
import DirectionsRunIcon from "@mui/icons-material/DirectionsRun";
import EventRepeatIcon from "@mui/icons-material/EventRepeat";

const Container = styled("div")`
  display: flex;
  flex-direction: column;
  border: solid 2px lightgray;
  border-radius: 6px 6px 0px 0px;
  height: calc(100vh - 80px);
  overflow: auto;
`;

const ContainerHeader = styled("div")`
  display: flex;
  flex-direction: row;
  border-bottom: solid 2px lightgray;
  padding: 2px 8px;
  flex-wrap: wrap;
  align-items: center;
`;

const Spacer = styled("div")`
  flex-grow: 1;
`;

const TreeContainer = styled(SimpleTreeView)`
  padding: 4px;
`;

const CustomTreeItem = styled(TreeItem)(({ theme }) => ({
  color: theme.palette.grey[200],
  [`& .${treeItemClasses.content}`]: {
    borderRadius: theme.spacing(0.5),
    padding: theme.spacing(0.5, 1),
    margin: theme.spacing(0.2, 0),
    [`& .${treeItemClasses.label}`]: {
      fontSize: "0.8rem",
      fontWeight: 500,
    },
  },
  [`& .${treeItemClasses.iconContainer}`]: {
    borderRadius: "50%",
    backgroundColor: theme.palette.primary.dark,
    padding: theme.spacing(0, 1.2),
    ...theme.applyStyles("light", {
      backgroundColor: alpha(theme.palette.primary.main, 0.25),
    }),
    ...theme.applyStyles("dark", {
      color: theme.palette.primary.contrastText,
    }),
  },
  [`& .${treeItemClasses.groupTransition}`]: {
    marginLeft: 15,
    paddingLeft: 18,
    borderLeft: `1px dashed ${alpha(theme.palette.text.primary, 0.4)}`,
  },
  ...theme.applyStyles("light", {
    color: theme.palette.grey[800],
  }),
}));

function Actions() {
  const details = useSelector((state: any) => state.projectData);
  return (
    <Container>
      <ContainerHeader>
        <Typography fontWeight={"bold"} color="#626c8a">
          Workflow
        </Typography>
        <Spacer></Spacer>
        <IconButton color="secondary">
          <CloseIcon />
        </IconButton>
        <IconButton color="secondary">
          <DownloadIcon />
        </IconButton>
        <IconButton color="secondary">
          <SystemUpdateAltIcon />
        </IconButton>
        <IconButton color="secondary">
          <SaveIcon />
        </IconButton>
        <IconButton color="secondary">
          <DirectionsRunIcon />
        </IconButton>
        <IconButton color="secondary" disabled>
          <EventRepeatIcon />
        </IconButton>
      </ContainerHeader>
      <TreeContainer defaultExpandedItems={["grid"]}>
        {details?.data?.workflow_steps.map((item: any, index: number) => {
          return (
            <CustomTreeItem itemId={item?.id} label={item.name_title}>
              <CustomTreeItem
                itemId={item?.id + index}
                label={
                  <table>
                    {Object.keys(item?.params_extra).map((oneKey, i) => {
                      if (oneKey === "id" || oneKey === "note") return null;
                      return (
                        <tr key={i}>
                          <td>{oneKey}</td>
                          <td>{` : ${item?.params_extra[oneKey]}`}</td>
                        </tr>
                      );
                    })}
                  </table>
                }
              />
            </CustomTreeItem>
          );
        })}
      </TreeContainer>
    </Container>
  );
}

export default Actions;
