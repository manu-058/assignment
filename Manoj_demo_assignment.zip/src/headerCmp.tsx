import React from "react";
import { useSelector } from "react-redux";
import { AppBar, Toolbar, Typography } from "@mui/material";

function Header() {
  const details = useSelector((state: any) => state.projectData);
  return (
    <AppBar position="static">
      <Toolbar variant="dense">
        <Typography variant="h6">{details?.data?.project_name}</Typography>
      </Toolbar>
    </AppBar>
  );
}

export default Header;
